# Fonctionnalités 
 - coloration syntaxique
 - snippets

# Utilisation
les fonctionnalités seront activées automatiquement sur n'importe fichier avec l'extension `.algo`. Pour les autres noms de fichier il faut appuyer sur le texte à gauche de la cloche (souvent c'est écrit `Plain Text`) pour activer la coloration syntaxique sur le fichier en cour d'édition.
 
# installation
## Méthode 1
dans visual studio code faites ctrl+p puis tapez (ou collez) `ext install nilsponsard.algo-papier-iut-aix`.
une pression sur la touche entrer devrait installer l'extension
## Méthode 2
- cliquez sur le bouton ![extension](https://github.com/sautax/algo-papier-iut-aix/raw/master/extension.png) pour afficher le panneau des extensions.
- Ensuite cherchez `nilsponsard` dans la barre de recherche, un seul résultat devrait apparaître.  
![recherche_extension](https://github.com/sautax/algo-papier-iut-aix/raw/master/recherche.png)
- il suffit ensuite de cliquer sur `algo papier iut aix` puis sur le bouton ![installer](https://github.com/sautax/algo-papier-iut-aix/raw/master/installer.png) en vert 

